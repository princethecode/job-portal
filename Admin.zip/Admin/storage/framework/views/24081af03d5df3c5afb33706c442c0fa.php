<?php $__env->startSection('title', 'Jobs Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Jobs Management</h2>
        <a href="<?php echo e(route('admin.jobs.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Add New Job
        </a>
    </div>
    
    <!-- Filters -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filter Jobs</h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.jobs.index')); ?>" method="GET">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Job title, company...">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" value="<?php echo e($filters['location'] ?? ''); ?>" placeholder="City, Country...">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="job_type" class="form-label">Job Type</label>
                        <select class="form-select" id="job_type" name="job_type">
                            <option value="">All Types</option>
                            <option value="Full-time" <?php echo e(isset($filters['job_type']) && $filters['job_type'] == 'Full-time' ? 'selected' : ''); ?>>Full-time</option>
                            <option value="Part-time" <?php echo e(isset($filters['job_type']) && $filters['job_type'] == 'Part-time' ? 'selected' : ''); ?>>Part-time</option>
                            <option value="Contract" <?php echo e(isset($filters['job_type']) && $filters['job_type'] == 'Contract' ? 'selected' : ''); ?>>Contract</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="category" class="form-label">Category</label>
                        <input type="text" class="form-control" id="category" name="category" value="<?php echo e($filters['category'] ?? ''); ?>" placeholder="IT, Finance...">
                    </div>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-1"></i> Apply Filters
                    </button>
                    <a href="<?php echo e(route('admin.jobs.index')); ?>" class="btn btn-secondary ms-2">
                        <i class="fas fa-redo me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger">
            <?php echo e($error); ?>

        </div>
    <?php else: ?>
        <!-- Jobs List -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">All Jobs</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Company</th>
                                <th>Location</th>
                                <th>Job Type</th>
                                <th>Category</th>
                                <th>Posting Date</th>
                                <th>Expiry Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($job->id); ?></td>
                                    <td><?php echo e($job->title); ?></td>
                                    <td><?php echo e($job->company); ?></td>
                                    <td><?php echo e($job->location); ?></td>
                                    <td><?php echo e($job->job_type); ?></td>
                                    <td><?php echo e($job->category); ?></td>
                                    <td><?php echo e($job->posting_date->format('M d, Y')); ?></td>
                                    <td><?php echo e($job->expiry_date->format('M d, Y')); ?></td>
                                    <td>
                                        <?php if($job->is_active): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('admin.jobs.show', $job->id)); ?>" 
                                               class="btn btn-sm btn-info" 
                                               title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.jobs.edit', $job->id)); ?>" 
                                               class="btn btn-sm btn-warning"
                                               title="Edit Job">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button type="button" 
                                                    class="btn btn-sm btn-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteModal<?php echo e($job->id); ?>"
                                                    title="Delete Job">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                        
                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo e($job->id); ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirm Delete</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to delete the job "<?php echo e($job->title); ?>"?
                                                        <p class="text-danger mt-2 mb-0">
                                                            <i class="fas fa-exclamation-triangle"></i>
                                                            This will also delete all associated applications.
                                                        </p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <form action="<?php echo e(route('admin.jobs.destroy', $job->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10" class="text-center">No jobs found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($jobs->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pareshgupta/Downloads/JobPortalProject_Essential/Admin/resources/views/jobs/index.blade.php ENDPATH**/ ?>