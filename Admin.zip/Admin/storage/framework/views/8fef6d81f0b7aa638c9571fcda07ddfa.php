<?php $__env->startSection('title', 'Job Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Job Details</h2>
        <div>
            <a href="<?php echo e(route('admin.jobs.edit', $job['id'])); ?>" class="btn btn-warning">
                <i class="fas fa-edit me-1"></i> Edit Job
            </a>
            <a href="<?php echo e(route('admin.jobs.index')); ?>" class="btn btn-secondary ms-2">
                <i class="fas fa-arrow-left me-1"></i> Back to Jobs
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <!-- Job Details Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Job Information</h6>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h3><?php echo e($job['title']); ?></h3>
                        <div class="d-flex flex-wrap mb-2">
                            <span class="badge bg-primary me-2 mb-1"><?php echo e($job['job_type']); ?></span>
                            <span class="badge bg-secondary me-2 mb-1"><?php echo e($job['category']); ?></span>
                            <?php if($job['is_active']): ?>
                                <span class="badge bg-success me-2 mb-1">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger me-2 mb-1">Inactive</span>
                            <?php endif; ?>
                        </div>
                        <div class="text-muted mb-3">
                            <p><i class="fas fa-building me-2"></i><?php echo e($job['company']); ?></p>
                            <p><i class="fas fa-map-marker-alt me-2"></i><?php echo e($job['location']); ?></p>
                            <?php if($job['salary']): ?>
                                <p><i class="fas fa-money-bill-wave me-2"></i><?php echo e($job['salary']); ?></p>
                            <?php endif; ?>
                            <p><i class="fas fa-calendar-alt me-2"></i>Posted: <?php echo e(\Carbon\Carbon::parse($job['posting_date'])->format('M d, Y')); ?></p>
                            <p><i class="fas fa-calendar-times me-2"></i>Expires: <?php echo e(\Carbon\Carbon::parse($job['expiry_date'])->format('M d, Y')); ?></p>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Job Description</h5>
                        <div class="p-3 bg-light rounded">
                            <?php echo nl2br(e($job['description'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Applications Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Applications</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Total Applications</h5>
                        <span class="badge bg-primary rounded-pill"><?php echo e(isset($applications['data']) ? count($applications['data']) : 0); ?></span>
                    </div>
                    
                    <div class="list-group">
                        <?php if(isset($applications['data']) && count($applications['data']) > 0): ?>
                            <?php $__currentLoopData = $applications['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('admin.applications.show', $application['id'])); ?>" class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1"><?php echo e($application['user']['name']); ?></h6>
                                        <small><?php echo e(\Carbon\Carbon::parse($application['applied_date'])->format('M d, Y')); ?></small>
                                    </div>
                                    <p class="mb-1"><?php echo e($application['user']['email']); ?></p>
                                    <small>
                                        <?php if($application['status'] == 'Applied'): ?>
                                            <span class="badge bg-primary">Applied</span>
                                        <?php elseif($application['status'] == 'Under Review'): ?>
                                            <span class="badge bg-info">Under Review</span>
                                        <?php elseif($application['status'] == 'Shortlisted'): ?>
                                            <span class="badge bg-success">Shortlisted</span>
                                        <?php elseif($application['status'] == 'Rejected'): ?>
                                            <span class="badge bg-danger">Rejected</span>
                                        <?php endif; ?>
                                    </small>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <p class="text-muted">No applications yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if(isset($applications['data']) && count($applications['data']) > 0): ?>
                        <div class="d-grid gap-2 mt-3">
                            <a href="<?php echo e(route('admin.applications.index', ['job_id' => $job['id']])); ?>" class="btn btn-primary">
                                View All Applications
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pareshgupta/Downloads/JobPortalProject_Essential/Admin/resources/views/jobs/show.blade.php ENDPATH**/ ?>