<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Dashboard</h2>
        <div class="btn-group">
            <button type="button" class="btn btn-outline-primary" onclick="window.print()">
                <i class="fas fa-print me-1"></i> Print Report
            </button>
        </div>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert alert-danger">
            <?php echo e($error); ?>

        </div>
    <?php else: ?>
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2 stats-card">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Users</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(number_format($stats['total_users'])); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-users fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2 stats-card">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Total Jobs</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(number_format($stats['total_jobs'])); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-briefcase fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2 stats-card">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Total Applications</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(number_format($stats['total_applications'])); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2 stats-card">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Active Jobs</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php echo e(number_format(App\Models\Job::where('is_active', true)->count())); ?>

                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clock fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row mb-4">
            <!-- Applications Trend Chart -->
            <div class="col-xl-8 col-lg-7">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Applications Trend (Last 30 Days)</h6>
                    </div>
                    <div class="card-body">
                        <canvas id="applicationTrendChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Applications by Status Chart -->
            <div class="col-xl-4 col-lg-5">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Applications by Status</h6>
                    </div>
                    <div class="card-body">
                        <canvas id="applicationStatusChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Second Charts Row -->
        <div class="row mb-4">
            <!-- Jobs by Type Chart -->
            <div class="col-xl-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Jobs by Type</h6>
                    </div>
                    <div class="card-body">
                        <canvas id="jobTypeChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Top Job Categories Chart -->
            <div class="col-xl-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Top Job Categories</h6>
                    </div>
                    <div class="card-body">
                        <canvas id="categoryChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activities and Applications -->
        <div class="row">
            <!-- Recent Activities -->
            <div class="col-xl-6 mb-4">
                <div class="card shadow">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Recent Activities</h6>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="timeline-item mb-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <?php if($activity['type'] === 'job'): ?>
                                                <i class="fas fa-briefcase text-primary"></i>
                                            <?php else: ?>
                                                <i class="fas fa-file-alt text-info"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <p class="mb-0"><?php echo e($activity['message']); ?></p>
                                            <small class="text-muted"><?php echo e($activity['date']->diffForHumans()); ?></small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-center text-muted">No recent activities</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Applications -->
            <div class="col-xl-6 mb-4">
                <div class="card shadow">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">Recent Applications</h6>
                        <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-sm btn-primary">
                            View All
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Applicant</th>
                                        <th>Job</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $stats['recent_applications']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($application->user->name); ?></td>
                                            <td><?php echo e($application->job->title); ?></td>
                                            <td>
                                                <?php switch($application->status):
                                                    case ('Applied'): ?>
                                                        <span class="badge bg-primary">Applied</span>
                                                        <?php break; ?>
                                                    <?php case ('Under Review'): ?>
                                                        <span class="badge bg-info">Under Review</span>
                                                        <?php break; ?>
                                                    <?php case ('Shortlisted'): ?>
                                                        <span class="badge bg-success">Shortlisted</span>
                                                        <?php break; ?>
                                                    <?php case ('Rejected'): ?>
                                                        <span class="badge bg-danger">Rejected</span>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <span class="badge bg-secondary"><?php echo e($application->status); ?></span>
                                                <?php endswitch; ?>
                                            </td>
                                            <td><?php echo e($application->created_at->format('M d, Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">No recent applications</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Application Trend Chart
    const trendCtx = document.getElementById('applicationTrendChart').getContext('2d');
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(collect($applicationTrend)->pluck('date')); ?>,
            datasets: [{
                label: 'Applications',
                data: <?php echo json_encode(collect($applicationTrend)->pluck('count')); ?>,
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    // Application Status Chart
    const statusCtx = document.getElementById('applicationStatusChart').getContext('2d');
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_keys($applicationsByStatus)); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($applicationsByStatus)); ?>,
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b'],
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Jobs by Type Chart
    const typeCtx = document.getElementById('jobTypeChart').getContext('2d');
    new Chart(typeCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_keys($jobsByType)); ?>,
            datasets: [{
                label: 'Jobs',
                data: <?php echo json_encode(array_values($jobsByType)); ?>,
                backgroundColor: '#36b9cc',
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    // Top Categories Chart
    const categoryCtx = document.getElementById('categoryChart').getContext('2d');
    new Chart(categoryCtx, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_keys($topCategories)); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($topCategories)); ?>,
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b'],
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.timeline-item {
    position: relative;
    padding-left: 1.5rem;
    border-left: 2px solid #e3e6f0;
}
.timeline-item:last-child {
    border-left-color: transparent;
}
.timeline-item .fas {
    position: absolute;
    left: -0.5rem;
    width: 1rem;
    height: 1rem;
    text-align: center;
    background: white;
    border-radius: 50%;
}
.stats-card {
    transition: transform 0.3s ease;
}
.stats-card:hover {
    transform: translateY(-5px);
}
@media print {
    .sidebar, .btn-group {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
    }
    .card {
        break-inside: avoid;
    }
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pareshgupta/Downloads/JobPortalProject_Essential/Admin/resources/views/dashboard/index.blade.php ENDPATH**/ ?>