package com.example.jobportal.ui.jobs;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
// Update to use the correct Job class
import com.example.jobportal.models.Job;
// Add the correct import for ApiResponse
import com.example.jobportal.models.ApiResponse;
import com.example.jobportal.network.ApiClient;
import com.example.jobportal.network.ApiService;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class JobsViewModel extends AndroidViewModel {
    private final MutableLiveData<List<Job>> jobs = new MutableLiveData<>();
    private final MutableLiveData<String> error = new MutableLiveData<>();
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final ApiService apiService;

    public JobsViewModel(Application application) {
        super(application);
        apiService = ApiClient.getApiService();
        loadJobs();
    }

    public LiveData<List<Job>> getJobs() {
        return jobs;
    }

    public LiveData<String> getError() {
        return error;
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public void loadJobs() {
        loading.setValue(true);
        apiService.getJobs().enqueue(new Callback<ApiResponse<List<com.example.jobportal.models.Job>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<com.example.jobportal.models.Job>>> call, 
                                 Response<ApiResponse<List<com.example.jobportal.models.Job>>> response) {
                loading.setValue(false);
                if (response.isSuccessful() && response.body() != null) {
                    // Add logging to see what's in the response
                    Log.d("JobsViewModel", "Response successful: " + response.body().isSuccess());
                    
                    // Check if data is a JobsData object with nested jobs list
                    if (response.body().getData() instanceof Map) {
                        try {
                            // Convert the data object to a map
                            Map<String, Object> dataMap = (Map<String, Object>) response.body().getData();
                            // Extract the nested "data" array that contains the actual jobs
                            if (dataMap.containsKey("data") && dataMap.get("data") instanceof List) {
                                List<Job> jobsList = (List<Job>) dataMap.get("data");
                                Log.d("JobsViewModel", "Extracted jobs count: " + jobsList.size());
                                jobs.setValue(jobsList);
                                return;
                            }
                        } catch (Exception e) {
                            Log.e("JobsViewModel", "Error parsing nested data: " + e.getMessage());
                        }
                    }
                    
                    // Fallback to original approach
                    if (response.body().getData() != null) {
                        Log.d("JobsViewModel", "Jobs count: " + response.body().getData().size());
                        jobs.setValue(response.body().getData());
                    } else {
                        Log.e("JobsViewModel", "Data is null in response");
                        error.setValue("No jobs data available");
                    }
                } else {
                    Log.e("JobsViewModel", "Response not successful: " + response.code());
                    error.setValue("Failed to load jobs: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<com.example.jobportal.models.Job>>> call, Throwable t) {
                loading.setValue(false);
                error.setValue(t.getMessage());
            }
        });
    }

    public void refreshJobs() {
        loadJobs();
    }
}