package com.example.jobportal.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import androidx.appcompat.app.AppCompatActivity;

import com.example.jobportal.MainActivity;
import com.example.jobportal.R;
// Change this import to use the network package instead of data.api
import com.example.jobportal.network.ApiClient;
import com.example.jobportal.databinding.ActivityLoginBinding;
import com.example.jobportal.models.ApiResponse;
import com.example.jobportal.models.User;
import com.example.jobportal.network.ApiCallback;
import com.example.jobportal.utils.TokenManager;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    
    private TextInputLayout tilEmail, tilPassword;
    private TextInputEditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvForgotPassword, tvRegister;
    private View progressBar;
    private ActivityLoginBinding binding;
    
    // User data to be passed after permissions
    private User authenticatedUser;
    private ApiClient apiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize API client with the correct constructor
        apiClient = new ApiClient(this);
        
        // Check if user is already logged in
        if (TokenManager.getInstance(this).hasToken()) {
            proceedToMainActivity();
            return;
        }

        // Initialize views
        initViews();
        
        // Set click listeners
        setupClickListeners();
    }

    private void initViews() {
        tilEmail = binding.emailLayout;
        tilPassword = binding.passwordLayout;
        etEmail = binding.emailInput;
        etPassword = binding.passwordInput;
        btnLogin = binding.loginButton;
        tvForgotPassword = binding.forgotPassword;
        tvRegister = binding.registerLink;
        progressBar = findViewById(R.id.progress_bar); // Make sure to add this to your layout
    }

    private void setupClickListeners() {
        btnLogin.setOnClickListener(v -> {
            if (validateInputs()) {
                attemptLogin();
            }
        });

        tvForgotPassword.setOnClickListener(v -> {
            // Navigate to forgot password screen
            navigateToForgotPassword();
        });

        tvRegister.setOnClickListener(v -> {
            // Navigate to registration screen
            navigateToRegister();
        });
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // Validate email
        String email = etEmail.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            tilEmail.setError("Email is required");
            isValid = false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Enter a valid email address");
            isValid = false;
        } else {
            tilEmail.setError(null);
        }

        // Validate password
        String password = etPassword.getText().toString().trim();
        if (TextUtils.isEmpty(password)) {
            tilPassword.setError("Password is required");
            isValid = false;
        } else if (password.length() < 6) {
            tilPassword.setError("Password must be at least 6 characters");
            isValid = false;
        } else {
            tilPassword.setError(null);
        }

        return isValid;
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
    
        // Show loading state
        showProgress(true);
        
        // Check for internet connectivity first
        if (!isNetworkAvailable()) {
            showProgress(false);
            Toast.makeText(this, "No internet connection. Please check your network settings and try again.", 
                    Toast.LENGTH_LONG).show();
            return;
        }
        
        // Call the API for login - this should now work with the correct ApiClient
        apiClient.login(email, password, new ApiCallback<ApiResponse<User>>() {
            @Override
            public void onSuccess(ApiResponse<User> response) {
                showProgress(false);
                if (response.isSuccess() && response.getData() != null) {
                    authenticatedUser = response.getData();
                    handleSuccessfulLogin();
                } else {
                    Toast.makeText(LoginActivity.this, 
                        response.getMessage() != null ? response.getMessage() : "Login failed", 
                        Toast.LENGTH_LONG).show();
                }
            }
    
            @Override
            public void onError(String errorMessage) {
                showProgress(false);
                
                // Check if it's a DNS or connection error
                if (errorMessage.contains("UnknownHostException") || 
                    errorMessage.contains("Unable to resolve host")) {
                    Toast.makeText(LoginActivity.this, 
                        "Cannot connect to server. Please check your internet connection or try again later.", 
                        Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(LoginActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    
    /**
     * Check if the device has an active internet connection
     */
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
                return capabilities != null && (
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                );
            } else {
                // For older Android versions
                NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
                return activeNetworkInfo != null && activeNetworkInfo.isConnected();
            }
        }
        return false;
    }
    
    private void handleSuccessfulLogin() {
        // Simply proceed to main activity without permission checks
        proceedToMainActivity();
    }
    
    private void proceedToMainActivity() {
        // Navigate to main activity
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        if (authenticatedUser != null) {
            intent.putExtra("user", authenticatedUser);
        }
        startActivity(intent);
        finish();
    }

    private void navigateToForgotPassword() {
        Intent intent = new Intent(this, ForgotPasswordActivity.class);
        startActivity(intent);
    }

    private void navigateToRegister() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
    
    private void showProgress(boolean show) {
        if (progressBar != null) {
            progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        }
        btnLogin.setEnabled(!show);
        btnLogin.setText(show ? "Logging in..." : "Login");
    }
}
