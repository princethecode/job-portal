package com.example.jobportal.util;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PermissionManager {
    // Constants
    private static final String PREFS_NAME = "PermissionPrefs";
    private static final String KEY_ASKED_ONCE = "AskedOnce_";
    
    // Basic permissions that are always required
    private static final String[] BASIC_PERMISSIONS = {
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE
    };
    
    // Notification permission (only for Android 13+)
    private static final String[] NOTIFICATION_PERMISSION = {
            Manifest.permission.POST_NOTIFICATIONS
    };
    
    // Storage permissions for Android < 13
    private static final String[] LEGACY_STORAGE_PERMISSIONS = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    
    // Media permissions for Android 13+ - only include if running on appropriate version
    private static String[] getModernStoragePermissions() {
        if (Build.VERSION.SDK_INT >= 33) { // Android 13
            try {
                return new String[] {
                    "android.permission.READ_MEDIA_IMAGES",
                    // READ_MEDIA_DOCUMENTS might not be available in some SDKs
                    // "android.permission.READ_MEDIA_DOCUMENTS"
                };
            } catch (Exception e) {
                // Fallback to just images if documents isn't available
                return new String[] {
                    "android.permission.READ_MEDIA_IMAGES"
                };
            }
        } else {
            return new String[0]; // Empty array for older versions
        }
    }
    
    // Get all required permissions based on Android version
    public static String[] getRequiredPermissions() {
        List<String> permissions = new ArrayList<>(Arrays.asList(BASIC_PERMISSIONS));
        
        // Add notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= 33) { // Android 13 (Tiramisu)
            permissions.addAll(Arrays.asList(NOTIFICATION_PERMISSION));
            permissions.addAll(Arrays.asList(getModernStoragePermissions()));
        } else {
            // For older Android versions, use legacy storage permissions
            permissions.addAll(Arrays.asList(LEGACY_STORAGE_PERMISSIONS));
        }
        
        return permissions.toArray(new String[0]);
    }
    
    // Check if all permissions are granted
    public static boolean hasAllPermissions(Context context, String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission) 
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
    
    // Get list of denied permissions
    public static String[] getDeniedPermissions(Context context, String[] permissions) {
        List<String> deniedPermissions = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission) 
                    != PackageManager.PERMISSION_GRANTED) {
                deniedPermissions.add(permission);
            }
        }
        return deniedPermissions.toArray(new String[0]);
    }
    
    // Request permissions from an Activity
    public static void requestPermissions(Activity activity, String[] permissions, int requestCode) {
        // Filter out permissions that are not needed based on Android version
        List<String> filteredPermissions = new ArrayList<>();
        for (String permission : permissions) {
            // Skip WRITE_EXTERNAL_STORAGE on Android 10+ as it's handled by scoped storage
            if (permission.equals(Manifest.permission.WRITE_EXTERNAL_STORAGE) && 
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                continue;
            }
            
            // Skip READ_EXTERNAL_STORAGE on Android 13+ as it's replaced by media permissions
            if (permission.equals(Manifest.permission.READ_EXTERNAL_STORAGE) && 
                    Build.VERSION.SDK_INT >= 33) { // Android 13
                continue;
            }
            
            // Skip Android 13 specific permissions on older versions using string comparison
            if ((permission.equals("android.permission.READ_MEDIA_IMAGES") || 
                 permission.equals("android.permission.READ_MEDIA_DOCUMENTS")) && 
                    Build.VERSION.SDK_INT < 33) { // Android 13
                continue;
            }
            
            // Skip notification permission on Android < 13
            if (permission.equals(Manifest.permission.POST_NOTIFICATIONS) && 
                    Build.VERSION.SDK_INT < 33) { // Android 13
                continue;
            }
            
            filteredPermissions.add(permission);
        }
        
        // Only request permissions if we have any after filtering
        if (!filteredPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(
                activity, 
                filteredPermissions.toArray(new String[0]), 
                requestCode
            );
        }
    }
    
    // Request permissions with explanation dialog if needed
    public static void requestPermissionsWithRationale(Activity activity, String[] permissions, 
                                                       String rationale, int requestCode) {
        // Filter to only permissions that need to be requested
        String[] deniedPermissions = getDeniedPermissions(activity, permissions);
        
        if (deniedPermissions.length == 0) {
            // All permissions already granted
            return;
        }
        
        boolean shouldShowRationale = false;
        for (String permission : deniedPermissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
                shouldShowRationale = true;
                break;
            }
        }
        
        if (shouldShowRationale) {
            showRationaleDialog(activity, rationale, deniedPermissions, requestCode);
        } else {
            if (!hasAskedForPermissionOnce(activity, deniedPermissions)) {
                markAskedForPermissionOnce(activity, deniedPermissions);
                requestPermissions(activity, deniedPermissions, requestCode);
            } else {
                // We've asked before and user denied with "Don't ask again"
                showSettingsDialog(activity);
            }
        }
    }
    
    // Show dialog explaining why we need permissions
    private static void showRationaleDialog(Activity activity, String rationale, 
                                           String[] permissions, int requestCode) {
        new AlertDialog.Builder(activity)
                .setTitle("Permission Required")
                .setMessage(rationale)
                .setPositiveButton("Grant", (dialog, which) -> {
                    requestPermissions(activity, permissions, requestCode);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                })
                .create()
                .show();
    }
    
    // Show dialog to send user to settings when they've permanently denied
    private static void showSettingsDialog(Activity activity) {
        new AlertDialog.Builder(activity)
                .setTitle("Permissions Required")
                .setMessage("Some permissions are required for this app to function properly. " +
                        "Please grant them in the app settings.")
                .setPositiveButton("Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
                    intent.setData(uri);
                    activity.startActivity(intent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                })
                .create()
                .show();
    }
    
    // Track if we've asked for permission before
    private static boolean hasAskedForPermissionOnce(Context context, String[] permissions) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        for (String permission : permissions) {
            if (!prefs.getBoolean(KEY_ASKED_ONCE + permission, false)) {
                return false;
            }
        }
        return true;
    }
    
    // Mark that we've asked for permissions
    private static void markAskedForPermissionOnce(Context context, String[] permissions) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        for (String permission : permissions) {
            editor.putBoolean(KEY_ASKED_ONCE + permission, true);
        }
        editor.apply();
    }
    
    /**
     * Shows a modal dialog requesting all required permissions at once.
     * This method should be called after user login.
     * 
     * @param activity The activity context
     * @param requestCode The request code to use for permission requests
     */
    public static void showAllPermissionsModalDialog(Activity activity, int requestCode) {
        // Get all required permissions
        String[] allPermissions = getRequiredPermissions();
        
        // Check which permissions are denied
        String[] deniedPermissions = getDeniedPermissions(activity, allPermissions);
        
        if (deniedPermissions.length == 0) {
            // All permissions already granted
            return;
        }
        
        // Create a formatted list of permissions for display
        StringBuilder permissionText = new StringBuilder();
        permissionText.append("This app requires the following permissions to function properly:\n\n");
        
        for (String permission : deniedPermissions) {
            String readableName = getReadablePermissionName(permission);
            permissionText.append("• ").append(readableName).append("\n");
        }
        
        // Show a non-cancelable dialog (modal)
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("Permissions Required")
                .setMessage(permissionText.toString())
                .setCancelable(false) // Make it modal
                .setPositiveButton("Grant All", (dialogInterface, i) -> {
                    requestPermissions(activity, deniedPermissions, requestCode);
                })
                .create();
        
        dialog.show();
    }
    
    /**
     * Converts permission strings to human-readable format
     */
    private static String getReadablePermissionName(String permission) {
        switch (permission) {
            case Manifest.permission.INTERNET:
                return "Internet Access";
            case Manifest.permission.ACCESS_NETWORK_STATE:
                return "Network State Access";
            case Manifest.permission.READ_EXTERNAL_STORAGE:
                return "Storage Access (Read)";
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                return "Storage Access (Write)";
            case Manifest.permission.POST_NOTIFICATIONS:
                return "Notifications";
            case "android.permission.READ_MEDIA_IMAGES":
                return "Photos & Images Access";
            case "android.permission.READ_MEDIA_DOCUMENTS":
                return "Documents Access";
            default:
                // Convert from "android.permission.SOMETHING" to "Something"
                String[] parts = permission.split("\\.");
                String lastPart = parts[parts.length - 1];
                String[] words = lastPart.split("_");
                StringBuilder readableName = new StringBuilder();
                for (String word : words) {
                    if (readableName.length() > 0) {
                        readableName.append(" ");
                    }
                    readableName.append(word.charAt(0)).append(word.substring(1).toLowerCase());
                }
                return readableName.toString();
        }
    }
}