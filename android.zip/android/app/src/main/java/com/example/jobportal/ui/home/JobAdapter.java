package com.example.jobportal.ui.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
// Update to use the correct Job class
import com.example.jobportal.models.Job;
import com.example.jobportal.databinding.ItemJobBinding;
import java.util.ArrayList;
import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.JobViewHolder> {
    
    private List<Job> jobs = new ArrayList<>();
    private final OnJobClickListener onItemClick;
    
    public interface OnJobClickListener {
        void onJobClick(Job job);
    }
    
    public JobAdapter(OnJobClickListener onItemClick) {
        this.onItemClick = onItemClick;
    }
    
    public void submitList(List<Job> newJobs) {
        this.jobs = newJobs;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public JobViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemJobBinding binding = ItemJobBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false
        );
        return new JobViewHolder(binding);
    }
    
    @Override
    public void onBindViewHolder(@NonNull JobViewHolder holder, int position) {
        holder.bind(jobs.get(position));
    }
    
    @Override
    public int getItemCount() {
        return jobs.size();
    }
    
    public class JobViewHolder extends RecyclerView.ViewHolder {
        private final ItemJobBinding binding;
        
        public JobViewHolder(@NonNull ItemJobBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            
            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick.onJobClick(jobs.get(position));
                }
            });
        }
        
        public void bind(Job job) {
            binding.jobTitle.setText(job.getTitle());
            binding.companyName.setText(job.getCompany());
            binding.location.setText(job.getLocation());
            binding.salary.setText(job.getSalary());
        }
    }
}